// Export pages
export '/auth1/auth1_widget.dart' show Auth1Widget;
export '/profile04/profile04_widget.dart' show Profile04Widget;
export '/mainpage/mainpage_widget.dart' show MainpageWidget;
export '/secondpage/secondpage_widget.dart' show SecondpageWidget;
export '/thirdpage/thirdpage_widget.dart' show ThirdpageWidget;
export '/forthpage/forthpage_widget.dart' show ForthpageWidget;
export '/page5/page5_widget.dart' show Page5Widget;
