package com.mycompany.talentserve

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
